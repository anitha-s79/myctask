<?php
$con=mysqli_connect("localhost","root","","myctask");
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}
