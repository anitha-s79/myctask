<?php
require "includes/common.php";
session_start();

$email = $_POST['eMail'];
$email = mysqli_real_escape_string($con, $email);

$pass = $_POST['password'];
$pass = mysqli_real_escape_string($con, $pass);
$pass = md5($pass);

$cpass = $_POST['cpassword'];
$cpass = mysqli_real_escape_string($con, $cpass);
$cpass = md5($cpass);


$first = $_POST['firstName'];
$first = mysqli_real_escape_string($con, $first);

$last = $_POST['lastName'];
$last = mysqli_real_escape_string($con, $last);

$mob = $_POST['number'];
$mob = mysqli_real_escape_string($con, $mob);

$query = "SELECT * from users where email_id='$email'";
$result = mysqli_query($con, $query);
$num = mysqli_num_rows($result);
if ($num != 0) {

    $m = "Email Already Exists";
    header('location: index.php?error=' . $m);

} else {
    if($pass==$cpass)
    {
    $quer = "INSERT INTO users(email_id,password,confirmpwd,first_name,last_name,mobile) values('$email','$pass','$cpass','$first','$last',$mob)";
    mysqli_query($con, $quer);

    echo "New record has id: " . mysqli_insert_id($con);
    $user_id = mysqli_insert_id($con);
    $_SESSION['email'] = $email;
    $_SESSION['user_id'] = $user_id;
    header('location:products.php');
    }
    else{
        $k = "Password doesn't match";
    header('location: index.php?perror=' . $k);
    }
}
?>