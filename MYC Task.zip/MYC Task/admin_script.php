<?php
require ("includes/common.php");
session_start();
$email = $_POST['aemail'];
$password = $_POST['apassword'];
if($email == 'admin@123' && $password == '12345'){
    header('location:products_manage.php');
}
else {
  echo "<script>alert('Invalid Credentials. Please check');</script>";

}
?>