<style>
  html {
    position: relative;
    min-height: 100%;
}
body{
    overflow-x:hidden;
    max-width: 100%;
    margin:0;
    margin-bottom: 150px;

}
body,
h1,
h2,
h3,
h4,
h5,
h6 {
    font-family: 'Andika';
    
}
#bg{
    background-image: url(https://source.unsplash.com/featured/?men,fashion,sneakers);
    /*https://images.unsplash.com/photo-1549942686-486aa99d2223*/
    background-repeat: no-repeat;
    min-height:600px;
    background-attachment: fixed;
    background-position: center;
    background-size:cover;
    text-align: center;
}
#banner_content {
    background-color: rgba(0, 0, 0, 0.7);
    
}
.carousel-inner img {
    width: 100%;
    height:100%;
}
.footer{
    position: absolute;
    margin-top: 50px;
    background-color: #141414;
    min-height:150px;
    padding-top:40px;
    width: 100%;
   
    bottom: 0;
    
}
.container  a {
    color:black;
}
.container a:hover{
    color:grey;
    
}
#size{
    max-height:200px;
}
</style>
<!--Navigation bar start-->
<nav class="navbar fixed-top navbar-expand-sm navbar-dark" style="background-color:rgba(0,0,0,0.5)">
            <div class="container">
                    <a href="#index" class="navbar-brand" style="font-family: 'Delius Swash Caps'">Stylish Vanguard</a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#mynavbar">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                <div class="collapse navbar-collapse" id="mynavbar">
                    <ul class="nav navbar-nav">
                       <li class="nav-item dropdown">
                           <a href="" class="nav-link dropdown-toggle" id="navbar-drop" data-toggle="dropdown">
                              Manage Products
                            </a>
                               <div class="dropdown-menu">
                                   <a href="add_products.php" class="dropdown-item">Add Products</a>
                                   <a href="update_products.php" class="dropdown-item">Update Products</a>
                                   <a href="delete_products.php" class="dropdown-item">Delete Products</a>
                               </div>
                           
                       </li>
                    </ul>
                </div>
            </div>
        </nav>
    <!--navigation bar end-->