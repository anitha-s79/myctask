<?php
require ("includes/common.php");
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Stylish Vanguard | Online Shopping Site for Men</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
  <link href='https://fonts.googleapis.com/css?family=Delius Swash Caps' rel='stylesheet'>
  <link href='https://fonts.googleapis.com/css?family=Andika' rel='stylesheet'>
  <link rel="stylesheet" href="style.css">
</head>
<body style="overflow-x:hidden; padding-bottom:100px;">
  <?php
        include 'includes/header_menu.php';
    ?>
  <div>
    <div class="container mt-5 ">
      <div class="row justify-content-around">
        <div class="col-md-5 mt-3">
          <h3 class="text-warning pt-3 title">Who We Are ?</h3>
          <hr />
          <img
            src="https://images.unsplash.com/photo-1490578474895-699cd4e2cf59?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=600&h=400&q=80"
            class="img-fluid d-block rounded mx-auto image-thumbnail">
          <p class="mt-2">Welcome to Stylish Vanguard - Your Ultimate Fashion Destination!
            At Stylish Vanguard, we believe that fashion is not just about clothes; it's an expression of individuality and style. Our online shopping site is dedicated to providing you with the latest trends, high-quality products, and an exceptional shopping experience. Let us take you on a journey through the world of fashion, where you can discover your unique style and stand out from the crowd.
            Our Vision:</br>

Our vision is to become the go-to destination for fashion enthusiasts who seek trendy, stylish, and affordable clothing and accessories. We aim to empower our customers to embrace their individuality and find confidence in expressing themselves through fashion. At Stylish Vanguard, we strive to curate a diverse range of products that cater to different tastes, body types, and styles, ensuring that there's something for everyone.
</p>
        </div>
        <div class="col-md-5 mt-3">
          <span class="text-warning pt-3">
            <h1 class="title">LIVE SUPPORT</h1>
            <h3>24 hours|7 days a week| 365 days a year Live Technical Support</h3>
          </span>
          <hr>
          <p>Our Collection:</br>

At Stylish Vanguard, we meticulously select each item in our collection to ensure that only the finest and trendiest products make it to our virtual shelves. Whether you're looking for chic dresses, comfortable loungewear, sophisticated workwear, or eye-catching accessories, we have it all. Our dedicated team of fashion experts constantly keeps an eye on the latest trends to bring you the most up-to-date and fashionable pieces.</br>
Customer Satisfaction:

Customer satisfaction is at the core of our values. We understand the importance of a seamless shopping experience, and that's why we've designed our website to be user-friendly, secure, and efficient. Our responsive customer support team is always ready to assist you with any inquiries, ensuring that you have a hassle-free shopping journey with us.

</br>Quality Assurance:</br>

We take pride in the quality of our products and the brands we collaborate with. Each item undergoes rigorous quality checks to meet our high standards. From the stitching to the fabric, we pay attention to every detail to ensure that our customers receive top-notch products that they can enjoy for years to come.

</br>Secure Shopping:</br>

At Stylish Vanguard, your security is our priority. We employ the latest encryption and security measures to safeguard your personal and financial information. You can shop with confidence, knowing that your data is protected.

</br>Join the Vanguard:</br>

We invite you to join our fashion-forward community and become a part of the Stylish Vanguard. Explore our vast selection, find pieces that resonate with your style, and embark on a fashion journey like no other.

</br>Thank you for choosing Stylish Vanguard as your fashion destination. Happy shopping!!
          </p>

        </div>
      </div>
    </div>
  </div>
  <div class="container pb-3">
  </div>
  <div class="container mt-3 d-flex justify-content-center card pb-3 col-md-6">

    <form class="col-md-12" action="https://formspree.io/EnterYourEmail" method="POST" name="_next">
      <h3 class="text-warning pt-3 title mx-auto">Contact Form</h3>
      <div class="form-group">
        <label for="exampleFormControlInput1">Email address</label>
        <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="Enter Your Email"
          name="email">
      </div>

      <div class="form-group">
        <label for="exampleFormControlTextarea1">Message</label>
        <textarea class="form-control" id="exampleFormControlTextarea1" name="message" rows="5"></textarea>
      </div>
      <input type="hidden" name="_next" value="http://localhost/foody/about.php" />
      <button type="submit" class="btn btn-primary">Submit</button>
    </form>
  </div>


  </div>
  <!--footer -->
  <?php include 'includes/footer.php'?>
  <!--footer end-->


</body>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
<script>
  $(document).ready(function () {
    $('[data-toggle="popover"]').popover();
  });
  $(document).ready(function () {

    if (window.location.href.indexOf('#login') != -1) {
      $('#login').modal('show');
    }

  });
</script>
<?php if(isset($_GET['error'])){ $z=$_GET['error']; echo "<script type='text/javascript'>
$(document).ready(function(){
$('#signup').modal('show');
});
</script>"; echo "
<script type='text/javascript'>alert('".$z."')</script>";} ?>
<?php if(isset($_GET['errorl'])){ $z=$_GET['errorl']; echo "<script type='text/javascript'>
$(document).ready(function(){
$('#login').modal('show');
});
</script>"; echo "
<script type='text/javascript'>alert('".$z."')</script>";} ?>
</html>
