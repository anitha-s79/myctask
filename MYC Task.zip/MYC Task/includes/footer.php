<footer class="footer">
    <div class="container text-center"><span class="text-muted"><b>Copyright&copy;Stylish Vanguard | All Rights Reserved | Contact Us: +91 00000 00000</b></span></div>
</footer>
    